def zadacka(a):
    a = a.lower().replace(" ", "")
    return a == a[::-1]
s = input("Ввод: ")
if zadacka(s):
    print("ПОЛИНДРОМ")
else:
    print("НЕТ")

