def proverka(a):
    if a <= 1:
        return False
    elif a <= 3:
        return True
    elif a % 2 == 0 or a % 3 == 0:
        return False
    b = 5
    while b * b <= a:
        if a % b == 0 or a % (b + 2) == 0:
            return False
        b += 6

vvod = int(input("Число: "))
if proverka(vvod):
    print(vvod, 'простое')
else:
    print(vvod, 'не простое')
