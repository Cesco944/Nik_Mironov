def calc(n1, n2, op):
    if op == '+':
        return n1 + n2
    elif op == '-':
        return n1 - n2
    elif op == '*':
        return n1 * n2
    elif op == '/':
        if n2 == 0:
            return 'ОТКАЗАНО!'
        else:
            return n1 / n2
    else:
        return 'НЕТ ТАКОЙ ОПЕРАЦИИ'

n1 = float(input('Первое: '))
n2 = float(input('Второе: '))
op = input('Введите операция (+, -, *, /): ')
res = calc(n1, n2, op)
print('Ответ: ', res)

