def reschenie():

    a = float(input('Первое: '))
    b = float(input('Второе: '))


    resh = (a + b) / 2

    return resh
otvet = reschenie()
print('Ответ: ', otvet)